import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.*
import java.lang.*;
import java.util.*;

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def map = message.getHeaders();
    def InterfaceName = map.get("InterfaceID") as String;
    def obj = ITApiFactory.getApi(ValueMappingApi.class, null);
    def mappedValue = obj.getMappedValue("InterfaceDetails", "InterfaceName", InterfaceName, "InterfaceDetails", "RecipientName");

    if (mappedValue == null)
    { throw new IllegalStateException("No valuemapping maintained for Interface: "+InterfaceName);
    }
    message.setProperty("RecipientName", mappedValue);
    return message;
}