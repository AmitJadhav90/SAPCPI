import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
       def body = message.getBody(java.lang.String);
     
       def map = message.getProperties();
       def ManualStartDate = map.get("ManualStartDate")
       def LogStartDate = map.get("LogStartDate")
       def LogEndDate = map.get("LogEndDate")
       def whereQuery
       if (LogStartDate ==''){
           message.setProperty ("StartDate", ManualStartDate)
       }else{
            message.setProperty ("StartDate", LogStartDate)
       }
       message.setProperty("EndDate", LogEndDate);
       return message;
}